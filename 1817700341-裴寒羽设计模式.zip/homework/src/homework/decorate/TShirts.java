package homework.decorate;

public class TShirts extends Finery{
	public void show(){
		super.show();
		System.out.println("大T恤");
		
	}
}
