package homework.decorate;

public class BigTrouser extends Finery{
	public void show(){
		super.show();
		System.out.println("阔腿裤");
	}
}
