package homework.decorate;

public class Sneakers extends Finery{
	public void show(){
		super.show();
		System.out.println("球鞋");
	}
}
