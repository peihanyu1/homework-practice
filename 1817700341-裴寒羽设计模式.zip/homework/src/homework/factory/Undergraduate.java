package homework.factory;

public class Undergraduate extends LeiFeng{
	
}
