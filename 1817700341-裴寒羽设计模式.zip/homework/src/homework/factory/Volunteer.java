package homework.factory;

public class Volunteer extends LeiFeng{

}
