package homework.factory;

public class VolunteerFacory implements LeiFengfactory{

	@Override
	public LeiFeng createLeiFeng() {
		return new Volunteer();
	}

}
