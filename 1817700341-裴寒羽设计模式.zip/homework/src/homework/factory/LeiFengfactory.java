package homework.factory;

public interface LeiFengfactory {
	LeiFeng createLeiFeng();
}
