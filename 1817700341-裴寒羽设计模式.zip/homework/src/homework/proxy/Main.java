package homework.proxy;

import java.io.Console;

public class Main {
	public static void main(String[] args) {
		SchoolGirl mm=new SchoolGirl();
		mm.setName("李娇娇");
		Proxy daili=new Proxy(mm);
		daili.GiveChocolate();
		daili.GiveDolls();
		daili.GiveFlowers();
		
	}
}
