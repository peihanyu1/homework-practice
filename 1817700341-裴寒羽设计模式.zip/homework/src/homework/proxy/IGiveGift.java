package homework.proxy;

public interface IGiveGift {
	void GiveDolls();
	void GiveFlowers();
	void GiveChocolate();
	
}
