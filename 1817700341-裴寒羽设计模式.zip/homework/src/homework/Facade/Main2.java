package homework.Facade;

public class Main2 {
	public static void main(String[] args) {
		Fund jijin=new Fund();
		jijin.buyFund();
		jijin.sellFund();
	}
	
	
}
