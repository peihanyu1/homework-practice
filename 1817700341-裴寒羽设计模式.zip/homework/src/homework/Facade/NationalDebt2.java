package homework.Facade;

public class NationalDebt2 {
	public void sell(){
		System.out.println("国债2卖出");
	}
	public void buy(){
		System.out.println("国债2买入");
	}
}
