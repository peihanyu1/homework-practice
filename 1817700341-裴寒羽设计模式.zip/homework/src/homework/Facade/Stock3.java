package homework.Facade;

public class Stock3 {
	public void sell(){
		System.out.println("股票3卖出");
	}
	public void buy(){
		System.out.println("股票3买入");
	}
}
